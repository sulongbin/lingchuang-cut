Read ../../STARTUP.md for the current bilingual personal-package startup.
