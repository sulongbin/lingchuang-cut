Read ../../MEDIA.md for the full bilingual global media binding contract and exact music-prepare result mapping.
