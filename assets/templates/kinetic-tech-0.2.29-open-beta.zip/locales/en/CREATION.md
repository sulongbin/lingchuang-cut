# Normal personal-package startup / 个人包正常启动

Read the public motion.lock.json and dependencies/runtime-dependencies.json. The bootstrap uses only the host Python standard library, so doctor and capabilities work before NumPy/jsonschema/OpenCV are installed. The locked production interpreter is Python3.13. Prefer an existing Python3.13 or an existing uv-managed3.13. The default system Python3.14 is not treated as compatible with these wheels. If no compatible interpreter exists, doctor names that concrete prerequisite. Setup never changes global Python.

先用正式个人包随包的已验签助手。不要截获临时核心、伪装python3、复制保护源码或在系统Python里乱装依赖。doctor/capabilities 不依赖第三方Python库；制作使用独立Python3.13环境。系统3.14不会被冒充为可安装这些锁定依赖。

Normal commands (the assistant fills real absolute paths; the user need not type them):

    node assistant/motion.mjs run <personal.motion> --instance <work> doctor
    node assistant/motion.mjs run <personal.motion> --instance <work> setup
    node assistant/motion.mjs run <personal.motion> --instance <work> capabilities
    node assistant/motion.mjs run <personal.motion> --instance <work> check-params --input <user.json>
    node assistant/motion.mjs run <personal.motion> --instance <work> plan --input <user.json> --out <work>/plan.json
    node assistant/motion.mjs run <personal.motion> --instance <work> prepare --input <user.json> --out <work>/project
    node assistant/motion.mjs run <personal.motion> --instance <work> preview --instance <work>/project --time 2 --out <work>/preview.png
    node assistant/motion.mjs run <personal.motion> --instance <work> render --instance <work>/project --out <work>/silent.mp4

The final sound result is silent-with-audio.mp4. All outputs need fresh paths. For an explicitly chosen external dependency-cache root, put --cache <cache-root> before the operation and keep using that root. The default is the platform's external MotionGit cache. Setup stores only the exact hashed Python wheels, locked Node dependencies and receipts there. It does not persist the helper's temporary template core. Rendering reuses that same isolated Python and explicitly loads playwright-core from this cache. Existing compatible Chrome/Chromium is used; explicit setup may install the standard Playwright headless shell into Playwright's own default browser cache if absent. FFmpeg/ffprobe and Node/npm remain declared host tools.

setup 会安装并核对完整锁定的Python与Node依赖，后续每一步使用同一Python，并从已核对外部缓存加载Node模块。依赖缓存与浏览器默认缓存可以保留复用；模板临时核心不作为安装目录。依赖失败须保留准确诊断；不要当作文稿太长、ASR不准或同步失败，也不能虚构 setup 成功。

For an author-owned open source checkout only, the same entry may be called as python3 kinetic_bootstrap.py doctor/setup/... . Personal consumption keeps the verified helper route above. Read AUDIO.md, NARRATION-MAP.md and DURATION.md for actual audio, phrase ownership and full-narration planning. Initial environment readiness, final encoded audio, actual action meaning and listening are separate checks.
