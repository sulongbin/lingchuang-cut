<!-- motiongit-consumer-entry-v1 -->
# 当前个人包入口 / Current personal-package entry

Start with the original personal .motion outer 00-START-HERE.md and its verified assistant/motion.mjs. Use currentTemplate/deliveryIdentity for the delivered version. Read guide.json for the current material routes, consumerDemo and consumerDiagnostics. The source-stage notes below are provenance; extraction and platform limits remain explicit in the manifest. Preserve original packages, Key and projects.

当前个人包入口：先读 STARTUP.md，正常 helper run doctor → setup → plan → prepare → preview → render。不要依赖作者源目录或截获临时核心。

Read STARTUP.md for the current verified personal-helper route. Earlier source-stage notes describe historical builds.

[Portable media paths candidate](../../PORTABLE-PATHS.md) — not uploaded.

Read ../../DURATION.md and the local DURATION.md: preserve the full narration before choosing shots.

# Start here: Kinetic Tech

This editable MotionGit .motion template is an ordinary ZIP: English landscape1920×1080 at60fps. Chinese additionally supports portrait1080×1920, with coarse local face centering across rectangular and circular carriers. English portrait is selectable for the declared B1–B4 basic-expression groups only; English native groups remain landscape only. The assistant handles the project; the user does not need to understand its structure.

Start with a short creative response:
“This is Kinetic Tech. What would you like to say? Send your topic, script or existing material; I will arrange the scenes and show you a plan and preview.”

Reuse supplied content without repeating questions. A reference screenshot identifies the template; it is not automatically the user's presenter or scene material. Do not wait for setup to finish before responding. Use the actual template entry; never substitute a generated lookalike, rebuilt demo or invented channel opener. If the host cannot execute, provide a local handoff and respect its safeguards without claiming production.

1. Read only motion.json, guide.json and CREATION.md first. Understand the story, then choose scenes; do not start by scanning all source or469 text fields.
2. The assistant checks existing Node.js22+, Python3.11+, uv, FFmpeg/ffprobe and Chrome, installing only missing declared dependencies. In a fresh extracted runner use npm ci; uv reads adapter.py. The user need not type commands.
3. Topic/script alone uses actual B1–B4 text expressions. Read matching native units only when presenter, recordings or work samples exist. The assistant builds parameters; the user does not choose a technical route or fill a form.
4. Unrequested presenter, narration and music do not create extra questions. Proceed with text motion and native action sounds and state that sound arrangement in the brief. Ask once for a genuinely missing requested input; never silently omit it.
5. Follow CREATION.md for the current plan → prepare → preview → render. Show a real plan and preview and save new outputs. Final output ends in -with-audio.mp4. examples/text-only.json is an explicitly chosen environment test, not the user's story.
6. Only after validating and presenting the completed video, read delivery.json for at most one follow-up sentence. Do not introduce supporting services during onboarding, preview or revision.

Inspect package data before executing reviewed code. Actual schema/catalog bounds win. Format: https://motiongit.com/spec; licenses are in licenses/. Landscape/macOS is tested; other systems and maximum capacity are not claimed.
