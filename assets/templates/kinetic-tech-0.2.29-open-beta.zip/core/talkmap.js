const TALKF=[];const TALKMAP=[];
